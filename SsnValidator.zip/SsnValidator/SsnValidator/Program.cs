﻿using SsnValidator.Services;

string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
string filePath = Path.Combine(baseDirectory, "../../../../identity_numbers.txt");


List<string> identityNumbers = [];
try
{
    identityNumbers = new List<string>(File.ReadAllLines(filePath));
}
catch(Exception e)
{
    Console.WriteLine("Failed to read input file with exception: " +e);
}

var validator = new IdentityNumberValidator();
validator.ValidateIdentityNumber(identityNumbers);

