﻿using System.Runtime.CompilerServices;

// needed to be able to reference and test core internal types (typically service implementations) in unit tests
[assembly: InternalsVisibleTo("UnitTests")]
