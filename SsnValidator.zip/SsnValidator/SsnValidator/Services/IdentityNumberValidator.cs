﻿namespace SsnValidator.Services;

internal class IdentityNumberValidator
{
    internal void ValidateIdentityNumber(List<string> numbers)
    {
        foreach (var number in numbers)
        {
            Console.WriteLine("Validating IdentityNumber " + number + "\n");

            try
            {
                var socialSecurityNumber = new SocialSecurityNumber(number);
                Console.WriteLine(socialSecurityNumber.Number + " is a valid " + nameof(SocialSecurityNumber) + "\n");
            }
            catch (Exception)
            {
                Console.WriteLine(number + " is not a valid " + nameof(SocialSecurityNumber) + "\n");
            }

            try
            {
                var coordinationNumber = new CoordinationNumber(number);
                Console.WriteLine(coordinationNumber.Number + " is a valid " + nameof(CoordinationNumber) + "\n");
            }
            catch (Exception)
            {
                Console.WriteLine(number + " is not a valid " + nameof(CoordinationNumber) + "\n");
            }

            try
            {
                var organizationNumber = new OrganizationNumber(number);
                Console.WriteLine(organizationNumber.Number + " is a valid " + nameof(OrganizationNumber) + "\n");
            }
            catch (Exception)
            {
                Console.WriteLine(number + " is not a valid " + nameof(OrganizationNumber) + "\n");
            }

            Console.WriteLine("\n");
        }
    }
}

