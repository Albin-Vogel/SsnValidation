﻿using SsnValidator.Domain;
using SsnValidator.Domain.Checks;

namespace SsnValidator;


internal class CoordinationNumber : IdentityNumber
{
    public CoordinationNumber(string number) : base(number) { }

    protected override bool IsValid(string number)
    {
        List<ValidityCheck> validityChecks = [new CoordinationBirthDateCheck(), new BirthNumberCheck(), new ControlDigitCheck()];
        var isValid = true;
        foreach (var check in validityChecks)
        {
            var validCheck = check.Check(number);
            if (validCheck is false)
            {
                Console.WriteLine("ValidityCheck " + check.GetType().Name + " failed when validating " + nameof(CoordinationNumber));
                isValid = false;
            }
        }
        return isValid;
    }
}

