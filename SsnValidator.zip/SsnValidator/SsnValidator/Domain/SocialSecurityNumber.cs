﻿using SsnValidator.Domain;
using SsnValidator.Domain.Checks;

namespace SsnValidator;


internal class SocialSecurityNumber : IdentityNumber
{
    internal SocialSecurityNumber(string number) : base(number) { }

    protected override bool IsValid(string number)
    {
        List<ValidityCheck> validityChecks = [new BirthDateCheck(), new BirthNumberCheck(), new ControlDigitCheck()];
        var isValid = true;
        foreach (var check in validityChecks)
        {
            var validCheck = check.Check(number);
            if (validCheck is false)
            {
                Console.WriteLine("ValidityCheck " + check.GetType().Name + " failed when validating " + nameof(SocialSecurityNumber));
                isValid = false;
            }
        }
        return isValid;
    }
}

