﻿namespace SsnValidator.Domain;


internal abstract class IdentityNumber
{
    internal string Number { get; private set; }

    protected IdentityNumber(string number)
    {
        if (IsValid(number) is false)
        {
            throw new ArgumentException("Invalid identity number.");
        }
        Number = number;
    }

    protected abstract bool IsValid(string number);
}

