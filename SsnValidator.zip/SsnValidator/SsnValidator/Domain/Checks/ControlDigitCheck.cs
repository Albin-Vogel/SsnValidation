﻿namespace SsnValidator.Domain.Checks;

internal class ControlDigitCheck : ValidityCheck
{
    internal override bool CheckInternal(string identityNumber)
    {
        var controlDigitString = identityNumber.Substring(identityNumber.Length - 1, 1);
        var controlDigit = int.Parse(controlDigitString);

        var formattedIdentityNumber = IdentityNumberToLuhnInputFormat(identityNumber);

        var luhnsDigit = LuhnsAlgorithm(formattedIdentityNumber);

        return controlDigit == luhnsDigit;
    }

    private static int LuhnsAlgorithm(string input)
    {
        var sum = 0;
        var alternate = true;

        for (var i = input.Length - 1; i >= 0; i--)
        {
            var n = int.Parse(input[i].ToString());

            if (alternate)
            {
                n *= 2;
                if (n > 9)
                {
                    n -= 9;
                }
            }

            sum += n;
            alternate = !alternate;
        }
        return (10 - sum % 10) % 10;
    }

    private static string IdentityNumberToLuhnInputFormat(string identityNumber)
    {
        identityNumber = identityNumber.Replace("-", string.Empty);
        identityNumber = identityNumber.Replace("+", string.Empty);
        switch (identityNumber.Length)
        {
            case 10:
                return identityNumber.Remove(identityNumber.Length - 1);
            case 12:
                var substring = identityNumber.Substring(2, identityNumber.Length - 2);
                return substring.Remove(substring.Length - 1);
            default:
                throw new ArgumentException();
        }
    }
}

