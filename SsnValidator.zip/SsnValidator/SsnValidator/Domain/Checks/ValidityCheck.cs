﻿namespace SsnValidator.Domain.Checks;

internal abstract class ValidityCheck
{
    internal bool Check(string identityNumber)
    {
        try
        {
            return CheckInternal(identityNumber);
        }
        catch (Exception)
        {
            return false;
        }
    }

    internal abstract bool CheckInternal(string identityNumber);
}

