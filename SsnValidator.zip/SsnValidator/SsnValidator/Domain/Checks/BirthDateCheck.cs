﻿using System.Globalization;

namespace SsnValidator.Domain.Checks;

internal class BirthDateCheck : ValidityCheck
{
    internal override bool CheckInternal(string identityNumber)
    {
        var birthDate = GetBirthDateFromSsn(identityNumber);
        if (birthDate == null)
        {
            return false;
        }

        return IsValidDate(birthDate);
    }

    private bool IsValidDate(string birthDate)
    {
        string format;
        switch (birthDate.Length)
        {
            case 6:
                format = "yyMMdd";
                break;
            case 8:
                format = "yyyyMMdd";
                break;
            default:
                throw new ArgumentException();
        }

        return DateTime.TryParseExact(birthDate, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out _);
    }

    private string GetBirthDateFromSsn(string identityNumber)
    {
        identityNumber = identityNumber.Replace("-", string.Empty);
        identityNumber = identityNumber.Replace("+", string.Empty);

        switch (identityNumber.Length)
        {
            case 10:
                return identityNumber.Substring(0, 6);
            case 12:
                return identityNumber.Substring(0, 8);
            default:
                throw new ArgumentException();
        }
    }
}

