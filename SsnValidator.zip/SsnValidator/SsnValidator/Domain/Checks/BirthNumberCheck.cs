﻿namespace SsnValidator.Domain.Checks;

internal class BirthNumberCheck : ValidityCheck
{
    internal override bool CheckInternal(string ssn)
    {
        var birthNumber = ssn.Substring(ssn.Length - 4, 3);
        return int.TryParse(birthNumber, out _);
    }
}

