﻿namespace SsnValidator.Domain.Checks;

internal class OrganizationDifferentiatorCheck : ValidityCheck
{
    private const int minimumDifferentiatorValue = 2;

    internal override bool CheckInternal(string ssn)
    {
        ssn = ssn.Replace("-", string.Empty);
        ssn = ssn.Replace("+", string.Empty);

        switch (ssn.Length)
        { 
            case 10:
                return int.Parse(ssn[2].ToString()) >= minimumDifferentiatorValue;
            case 12:
                return int.Parse(ssn[4].ToString()) >= minimumDifferentiatorValue;
            default:
                return false;
        }
    }
}

