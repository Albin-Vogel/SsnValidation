﻿using System.Globalization;

namespace SsnValidator.Domain.Checks;

internal class CoordinationBirthDateCheck : ValidityCheck
{
    internal override bool CheckInternal(string identityNumber)
    {
        var coordinationBirthDate = GetCoordinationBirthDateFromIdentityNumber(identityNumber);
        var birthDate = GetBirthDateFromCoordinationDate(coordinationBirthDate);

        return IsValidDate(birthDate);
    }

    private bool IsValidDate(string birthDate)
    {
        string format;
        switch (birthDate.Length)
        {
            case 6:
                format = "yyMMdd";
                break;
            case 8:
                format = "yyyyMMdd";
                break;
            default:
                throw new ArgumentException();
        }

        return DateTime.TryParseExact(birthDate, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out _);
    }

    private string GetCoordinationBirthDateFromIdentityNumber(string identityNumber)
    {
        identityNumber = identityNumber.Replace("-", string.Empty);
        identityNumber = identityNumber.Replace("+", string.Empty);

        switch (identityNumber.Length)
        {
            case 10:
                return identityNumber.Substring(0, 6);
            case 12:
                return identityNumber.Substring(0, 8);
            default:
                throw new ArgumentException();
        }
    }

    private string GetBirthDateFromCoordinationDate(string coordinationBirthDate)
    {
        var yearMonth = coordinationBirthDate.Substring(0, coordinationBirthDate.Length - 2);
        var coordinationDay = coordinationBirthDate.Substring(coordinationBirthDate.Length - 2, 2);
        var day = (int.Parse(coordinationDay) - 60).ToString();
        return yearMonth + day;
    }
}

