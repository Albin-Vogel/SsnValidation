using SsnValidator;

namespace UnitTests
{
    public class OrganizationNumberInitializationTests
    {
        [Theory]
        [InlineData("556614-3185")]
        [InlineData("16556614-3185")]
        [InlineData("5566143185")]
        public void OrganizationNumberInitializedForValidIdentityNumber(string identityNumber)
        {
            var organizationNumber = new OrganizationNumber(identityNumber);

            Assert.Equal(identityNumber, organizationNumber.Number);
        }
        [Theory]
        [InlineData("551614-3185")]
        [InlineData("556614+3185")]
        [InlineData("15556614-3185")]
        [InlineData("aa556614-3185")]
        public void OrganizationNumberNotInitializedForInvalidIdentityNumber(string identityNumber)
        {
            Assert.Throws<ArgumentException>(() => new OrganizationNumber(identityNumber));
        }
    }
}