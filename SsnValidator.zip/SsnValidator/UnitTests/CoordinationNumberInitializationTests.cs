using SsnValidator;

namespace UnitTests
{
    public class CoordinationNumberInitializationTests
    {
        [Theory]
        [InlineData("190910799824")]
        [InlineData("0910799824")]
        public void CoordinationNumberInitializedForValidIdentityNumber(string identityNumber)
        {
            var coordinationNumber = new CoordinationNumber(identityNumber);

            Assert.Equal(identityNumber, coordinationNumber.Number);
        }
        [Theory]
        [InlineData("190910799820")]
        [InlineData("0910929824")]
        [InlineData("0910209824")]
        public void CoordinationNumberNotInitializedForInvalidIdentityNumber(string identityNumber)
        {
            Assert.Throws<ArgumentException>(() => new CoordinationNumber(identityNumber));
        }
    }
}