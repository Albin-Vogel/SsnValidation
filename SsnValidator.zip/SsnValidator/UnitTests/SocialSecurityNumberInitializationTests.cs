using SsnValidator;

namespace UnitTests
{
    public class SocialSecurityNumberInitializationTests
    {
        [Theory]
        [InlineData("199802179557")]
        [InlineData("9802179557")]
        [InlineData("980217-9557")]
        [InlineData("980217+9557")]
        public void SocialSecurityNumberInitializedForValidIdentityNumber(string identityNumber)
        {
            var socialSecurityNumber = new SocialSecurityNumber(identityNumber);

            Assert.Equal(identityNumber, socialSecurityNumber.Number);
        }
        [Theory]
        [InlineData("980231-9557")]
        [InlineData("980217-9550")]
        [InlineData("9802170-9557")]
        [InlineData("980217-95570")]
        public void SocialSecurityNumberNotInitializedForInvalidIdentityNumber(string identityNumber)
        {
            Assert.Throws<ArgumentException>(() => new SocialSecurityNumber(identityNumber));
        }
    }
}