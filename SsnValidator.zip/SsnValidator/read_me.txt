Run "build_and_run.bat" to execute the identity number validation program.

Run "build_and_run_tests.bat" to run unit tests for the identity number validation program.

The program reads data from "identity_numbers.txt". An identity number needs to be placed in its own row. 